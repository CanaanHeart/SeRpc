#include "Addition.h"

namespace MathFunctions {
double add(double x, double y)
{
  return x + y;
}
}
